package com.codenotfound.primefaces;

import org.primefaces.model.menu.*;

import javax.annotation.PostConstruct;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.ViewScoped;
import javax.inject.Named;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

@Named
public class TabBean {
    private List<TabInfo> tabs;

    @PostConstruct
    public void init() {
          tabs = Arrays.asList(new TabInfo("Kategorie", "Kategorie"),new TabInfo("Auswertung", "Auswertung"),
        		  new TabInfo("Auswertungspunkte", "Auswertungspunkte"),new TabInfo("Regler", "Regler"),
                  new TabInfo("Zuweisung", "Zuweisung"), new TabInfo("Weiter", "Weiter")
                  );
    }

    public List<TabInfo> getTabs() {
        return tabs;
    }
}